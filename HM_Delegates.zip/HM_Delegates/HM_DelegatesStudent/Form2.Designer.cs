﻿
namespace HM_DelegatesStudent
{
    partial class Form2
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.NameText = new System.Windows.Forms.TextBox();
            this.IdText = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.LastNameText = new System.Windows.Forms.TextBox();
            this.GradeText = new System.Windows.Forms.TextBox();
            this.AgeText = new System.Windows.Forms.TextBox();
            this.CostText = new System.Windows.Forms.TextBox();
            this.PaidText = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.AvarageGradesText = new System.Windows.Forms.TextBox();
            this.ToPayText = new System.Windows.Forms.TextBox();
            this.AvarageAgeText = new System.Windows.Forms.TextBox();
            this.AllPaysText = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "First Name";
            // 
            // NameText
            // 
            this.NameText.Location = new System.Drawing.Point(117, 73);
            this.NameText.Name = "NameText";
            this.NameText.Size = new System.Drawing.Size(150, 31);
            this.NameText.TabIndex = 2;
            // 
            // IdText
            // 
            this.IdText.Location = new System.Drawing.Point(117, 22);
            this.IdText.Name = "IdText";
            this.IdText.Size = new System.Drawing.Size(150, 31);
            this.IdText.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(316, 86);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 59);
            this.button1.TabIndex = 4;
            this.button1.Text = "Add Student";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Location = new System.Drawing.Point(316, 151);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(401, 229);
            this.listBox1.TabIndex = 5;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(727, 86);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(161, 59);
            this.button3.TabIndex = 6;
            this.button3.Text = "Chack Grades";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Last Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 290);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "Cost";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 242);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Age";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Grade";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 342);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 25);
            this.label7.TabIndex = 11;
            this.label7.Text = "Paid";
            // 
            // LastNameText
            // 
            this.LastNameText.Location = new System.Drawing.Point(117, 137);
            this.LastNameText.Name = "LastNameText";
            this.LastNameText.Size = new System.Drawing.Size(150, 31);
            this.LastNameText.TabIndex = 13;
            // 
            // GradeText
            // 
            this.GradeText.Location = new System.Drawing.Point(117, 191);
            this.GradeText.Name = "GradeText";
            this.GradeText.Size = new System.Drawing.Size(150, 31);
            this.GradeText.TabIndex = 12;
            // 
            // AgeText
            // 
            this.AgeText.Location = new System.Drawing.Point(117, 242);
            this.AgeText.Name = "AgeText";
            this.AgeText.Size = new System.Drawing.Size(150, 31);
            this.AgeText.TabIndex = 15;
            // 
            // CostText
            // 
            this.CostText.Location = new System.Drawing.Point(117, 291);
            this.CostText.Name = "CostText";
            this.CostText.Size = new System.Drawing.Size(150, 31);
            this.CostText.TabIndex = 14;
            // 
            // PaidText
            // 
            this.PaidText.Location = new System.Drawing.Point(117, 339);
            this.PaidText.Name = "PaidText";
            this.PaidText.Size = new System.Drawing.Size(150, 31);
            this.PaidText.TabIndex = 16;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(520, 86);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(180, 59);
            this.button2.TabIndex = 17;
            this.button2.Text = "Remove Student";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // AvarageGradesText
            // 
            this.AvarageGradesText.Location = new System.Drawing.Point(882, 342);
            this.AvarageGradesText.Name = "AvarageGradesText";
            this.AvarageGradesText.Size = new System.Drawing.Size(150, 31);
            this.AvarageGradesText.TabIndex = 25;
            // 
            // ToPayText
            // 
            this.ToPayText.Location = new System.Drawing.Point(882, 245);
            this.ToPayText.Name = "ToPayText";
            this.ToPayText.Size = new System.Drawing.Size(150, 31);
            this.ToPayText.TabIndex = 24;
            // 
            // AvarageAgeText
            // 
            this.AvarageAgeText.Location = new System.Drawing.Point(882, 293);
            this.AvarageAgeText.Name = "AvarageAgeText";
            this.AvarageAgeText.Size = new System.Drawing.Size(150, 31);
            this.AvarageAgeText.TabIndex = 23;
            // 
            // AllPaysText
            // 
            this.AllPaysText.Location = new System.Drawing.Point(882, 194);
            this.AllPaysText.Name = "AllPaysText";
            this.AllPaysText.Size = new System.Drawing.Size(150, 31);
            this.AllPaysText.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(739, 348);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 25);
            this.label8.TabIndex = 21;
            this.label8.Text = "Avarage Grades";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(739, 299);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 25);
            this.label9.TabIndex = 20;
            this.label9.Text = "Avarage Age";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(739, 251);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 25);
            this.label10.TabIndex = 19;
            this.label10.Text = "To Pay";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(739, 200);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 25);
            this.label11.TabIndex = 18;
            this.label11.Text = "All Pays";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(920, 86);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(153, 59);
            this.button4.TabIndex = 26;
            this.button4.Text = "Chack Name";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1205, 564);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.AvarageGradesText);
            this.Controls.Add(this.ToPayText);
            this.Controls.Add(this.AvarageAgeText);
            this.Controls.Add(this.AllPaysText);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.PaidText);
            this.Controls.Add(this.AgeText);
            this.Controls.Add(this.CostText);
            this.Controls.Add(this.LastNameText);
            this.Controls.Add(this.GradeText);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.IdText);
            this.Controls.Add(this.NameText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox NameText;
        private System.Windows.Forms.TextBox IdText;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox LastNameText;
        private System.Windows.Forms.TextBox GradeText;
        private System.Windows.Forms.TextBox AgeText;
        private System.Windows.Forms.TextBox CostText;
        private System.Windows.Forms.TextBox PaidText;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox AvarageGradesText;
        private System.Windows.Forms.TextBox ToPayText;
        private System.Windows.Forms.TextBox AvarageAgeText;
        private System.Windows.Forms.TextBox AllPaysText;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button4;
    }
}

