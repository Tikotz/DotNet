﻿namespace HM_Delegates
{
    public delegate bool FilterStudent(Student student);
    public delegate int Filtersums(Student student);
    public delegate double FilterAverage(Student student);
}