﻿using DelegatesAndEvents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events2
{
    public static class StudentListEvents
    {
        public static List<StudentEvent> students = new List<StudentEvent>();
    }
}
