﻿namespace HackerWe.UI
{
    partial class ClientsUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.IdtextBox1 = new System.Windows.Forms.TextBox();
            this.IDNtextBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.FirstNametextBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.LastNametextBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.PhoneNumbertextBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.EmailtextBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblMessegeTxt = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Id: ";
            // 
            // IdtextBox1
            // 
            this.IdtextBox1.Location = new System.Drawing.Point(176, 28);
            this.IdtextBox1.Name = "IdtextBox1";
            this.IdtextBox1.Size = new System.Drawing.Size(197, 31);
            this.IdtextBox1.TabIndex = 1;
            // 
            // IDNtextBox2
            // 
            this.IDNtextBox2.Location = new System.Drawing.Point(176, 80);
            this.IDNtextBox2.Name = "IDNtextBox2";
            this.IDNtextBox2.Size = new System.Drawing.Size(197, 31);
            this.IDNtextBox2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Identity Number: ";
            // 
            // FirstNametextBox3
            // 
            this.FirstNametextBox3.Location = new System.Drawing.Point(176, 143);
            this.FirstNametextBox3.Name = "FirstNametextBox3";
            this.FirstNametextBox3.Size = new System.Drawing.Size(197, 31);
            this.FirstNametextBox3.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "First Name: ";
            // 
            // LastNametextBox4
            // 
            this.LastNametextBox4.Location = new System.Drawing.Point(176, 201);
            this.LastNametextBox4.Name = "LastNametextBox4";
            this.LastNametextBox4.Size = new System.Drawing.Size(197, 31);
            this.LastNametextBox4.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 204);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Last Name: ";
            // 
            // PhoneNumbertextBox5
            // 
            this.PhoneNumbertextBox5.Location = new System.Drawing.Point(176, 317);
            this.PhoneNumbertextBox5.Name = "PhoneNumbertextBox5";
            this.PhoneNumbertextBox5.Size = new System.Drawing.Size(197, 31);
            this.PhoneNumbertextBox5.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 320);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(141, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "Phone Number: ";
            // 
            // EmailtextBox6
            // 
            this.EmailtextBox6.Location = new System.Drawing.Point(176, 259);
            this.EmailtextBox6.Name = "EmailtextBox6";
            this.EmailtextBox6.Size = new System.Drawing.Size(197, 31);
            this.EmailtextBox6.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 262);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Email: ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(19, 392);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(354, 63);
            this.button1.TabIndex = 12;
            this.button1.Text = "Add Client";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblMessegeTxt
            // 
            this.lblMessegeTxt.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lblMessegeTxt.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblMessegeTxt.Location = new System.Drawing.Point(394, 27);
            this.lblMessegeTxt.Name = "lblMessegeTxt";
            this.lblMessegeTxt.Size = new System.Drawing.Size(571, 144);
            this.lblMessegeTxt.TabIndex = 18;
            this.lblMessegeTxt.Text = "";
            // 
            // ClientsUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HackerWe.UI.Properties.Resources.library_photo;
            this.Controls.Add(this.lblMessegeTxt);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.PhoneNumbertextBox5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.EmailtextBox6);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.LastNametextBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.FirstNametextBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.IDNtextBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.IdtextBox1);
            this.Controls.Add(this.label1);
            this.Name = "ClientsUserControl";
            this.Size = new System.Drawing.Size(993, 552);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox IdtextBox1;
        private System.Windows.Forms.TextBox IDNtextBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox FirstNametextBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox LastNametextBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox PhoneNumbertextBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EmailtextBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox lblMessegeTxt;
    }
}
