﻿
namespace HackerWe.UI
{
    partial class BooksUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Add_Book = new System.Windows.Forms.Button();
            this.Id = new System.Windows.Forms.Label();
            this.IdtextBox1 = new System.Windows.Forms.TextBox();
            this.IDNtextBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AuthortextBox3 = new System.Windows.Forms.TextBox();
            this.Author = new System.Windows.Forms.Label();
            this.NametextBox4 = new System.Windows.Forms.TextBox();
            this.Name = new System.Windows.Forms.Label();
            this.NumberPagestextBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.NumberCopiestextBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblMessegeTxt = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // Add_Book
            // 
            this.Add_Book.Location = new System.Drawing.Point(16, 408);
            this.Add_Book.Name = "Add_Book";
            this.Add_Book.Size = new System.Drawing.Size(477, 58);
            this.Add_Book.TabIndex = 1;
            this.Add_Book.Text = "Add Book";
            this.Add_Book.UseVisualStyleBackColor = true;
            this.Add_Book.Click += new System.EventHandler(this.Add_Book_Click);
            // 
            // Id
            // 
            this.Id.AutoSize = true;
            this.Id.Location = new System.Drawing.Point(16, 14);
            this.Id.Name = "Id";
            this.Id.Size = new System.Drawing.Size(37, 25);
            this.Id.TabIndex = 2;
            this.Id.Text = "Id: ";
            // 
            // IdtextBox1
            // 
            this.IdtextBox1.Location = new System.Drawing.Point(193, 14);
            this.IdtextBox1.Name = "IdtextBox1";
            this.IdtextBox1.Size = new System.Drawing.Size(150, 31);
            this.IdtextBox1.TabIndex = 3;
            // 
            // IDNtextBox2
            // 
            this.IDNtextBox2.Location = new System.Drawing.Point(193, 68);
            this.IDNtextBox2.Name = "IDNtextBox2";
            this.IDNtextBox2.Size = new System.Drawing.Size(150, 31);
            this.IDNtextBox2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Identity Number: ";
            // 
            // AuthortextBox3
            // 
            this.AuthortextBox3.Location = new System.Drawing.Point(193, 117);
            this.AuthortextBox3.Name = "AuthortextBox3";
            this.AuthortextBox3.Size = new System.Drawing.Size(150, 31);
            this.AuthortextBox3.TabIndex = 7;
            // 
            // Author
            // 
            this.Author.AutoSize = true;
            this.Author.Location = new System.Drawing.Point(16, 117);
            this.Author.Name = "Author";
            this.Author.Size = new System.Drawing.Size(71, 25);
            this.Author.TabIndex = 6;
            this.Author.Text = "Author:";
            // 
            // NametextBox4
            // 
            this.NametextBox4.Location = new System.Drawing.Point(193, 166);
            this.NametextBox4.Name = "NametextBox4";
            this.NametextBox4.Size = new System.Drawing.Size(150, 31);
            this.NametextBox4.TabIndex = 9;
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Location = new System.Drawing.Point(16, 166);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(68, 25);
            this.Name.TabIndex = 8;
            this.Name.Text = "Name: ";
            // 
            // NumberPagestextBox5
            // 
            this.NumberPagestextBox5.Location = new System.Drawing.Point(193, 215);
            this.NumberPagestextBox5.Name = "NumberPagestextBox5";
            this.NumberPagestextBox5.Size = new System.Drawing.Size(150, 31);
            this.NumberPagestextBox5.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 215);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(162, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "Number Of Pages: ";
            // 
            // NumberCopiestextBox6
            // 
            this.NumberCopiestextBox6.Location = new System.Drawing.Point(193, 271);
            this.NumberCopiestextBox6.Name = "NumberCopiestextBox6";
            this.NumberCopiestextBox6.Size = new System.Drawing.Size(150, 31);
            this.NumberCopiestextBox6.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 271);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "Number Of Copies: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 324);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 25);
            this.label7.TabIndex = 15;
            this.label7.Text = "Date Published: ";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(193, 319);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(300, 31);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // lblMessegeTxt
            // 
            this.lblMessegeTxt.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lblMessegeTxt.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblMessegeTxt.Location = new System.Drawing.Point(364, 14);
            this.lblMessegeTxt.Name = "lblMessegeTxt";
            this.lblMessegeTxt.Size = new System.Drawing.Size(696, 144);
            this.lblMessegeTxt.TabIndex = 17;
            this.lblMessegeTxt.Text = "";
            // 
            // BooksUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HackerWe.UI.Properties.Resources.library_photo;
            this.Controls.Add(this.lblMessegeTxt);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.NumberCopiestextBox6);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.NumberPagestextBox5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.NametextBox4);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.AuthortextBox3);
            this.Controls.Add(this.Author);
            this.Controls.Add(this.IDNtextBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.IdtextBox1);
            this.Controls.Add(this.Id);
            this.Controls.Add(this.Add_Book);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Size = new System.Drawing.Size(1095, 754);
            this.Load += new System.EventHandler(this.BooksUserControl_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Add_Book;
        private System.Windows.Forms.Label Id;
        private System.Windows.Forms.TextBox IdtextBox1;
        private System.Windows.Forms.TextBox IDNtextBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox AuthortextBox3;
        private System.Windows.Forms.Label Author;
        private System.Windows.Forms.TextBox NametextBox4;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.TextBox NumberPagestextBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox NumberCopiestextBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.RichTextBox lblMessegeTxt;
    }
}
