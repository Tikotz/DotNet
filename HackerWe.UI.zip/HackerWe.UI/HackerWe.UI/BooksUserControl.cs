﻿using HackerWe.Entities;
using HackerWe.Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HackerWe.UI
{
    public partial class BooksUserControl : UserControl
    {
        public BooksUserControl()
        {
            InitializeComponent();
        }

        private void BooksUserControl_Load(object sender, EventArgs e)
        {
            
        }

        private void Add_Book_Click(object sender, EventArgs e)
        {
            Library.Books.Add(new Book { Id = int.Parse(IdtextBox1.Text), IdentityNumber = IDNtextBox2.Text, Author = AuthortextBox3.Text, Name = NametextBox4.Text, NumberOfPages = int.Parse(NumberPagestextBox5.Text), NumberOfCopies = short.Parse(NumberCopiestextBox6.Text),DatePublished = dateTimePicker1.Value });
            Library.SaveBooksAsJSON();
            lblMessegeTxt.Text = "Book Added Succesfully";
        }
    }
}
