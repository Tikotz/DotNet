﻿using HackerWe.Logic;
using HackerWe.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace HackerWe.UI
{
    public partial class ClientsUserControl : UserControl
    {
        Client newClient = new Client();
        public event Action<Client> clientadded;
        public ClientsUserControl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblMessegeTxt.Text = "";
            if (Client.IsEmailValid(EmailtextBox6.Text) && Client.IsFNameValid(FirstNametextBox3.Text + " " + LastNametextBox4.Text) && Client.IsDecimal(IdtextBox1.Text ) && Client.IsDecimal( IDNtextBox2.Text) && Client.IsDecimal(PhoneNumbertextBox5.Text ))
            {
                newClient.Id = int.Parse(IdtextBox1.Text);
                newClient.IdentityNumber = IDNtextBox2.Text;
                newClient.FirstName = FirstNametextBox3.Text;
                newClient.LastName = LastNametextBox4.Text;
                newClient.PhoneNumber = PhoneNumbertextBox5.Text;
                newClient.Email = EmailtextBox6.Text;

                Library.SaveClientsAsJson();
                Library.Clients.Insert(0,newClient);
                lblMessegeTxt.Text = "Client Added Succesfully";
                clientadded(newClient);
            }
            else
            {
                if (!Client.IsEmailValid(EmailtextBox6.Text))
                {
                    lblMessegeTxt.Text = "Email is not valid";
                    return;
                }
                if (!Client.IsFNameValid(FirstNametextBox3.Text + " " + LastNametextBox4.Text))
                {
                   lblMessegeTxt.Text = "Youre first name OR last name is not valid";
                    return ;
                }
                lblMessegeTxt.Text = "one or more of the following information is not valid";
            }
        }
    }
}
