﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HackerWe.Entities
{
    public class Client
    {
        public int Id { get; set; }
        public string IdentityNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName => FirstName + " " + LastName;
        public string Email { get; set; }
        public string PhoneNumber { get; set; }


        public static bool IsEmailValid(string mail)
        {
            string pattern = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
            return Regex.Match(mail, pattern).Success;
        }
        public static bool IsFNameValid(string fullame)
        {
            string IsValidName = @"\D{2,18} \D{2,18}";
            return Regex.Match(fullame,IsValidName).Success;
        }
        public static bool IsDecimal(string num)
        {
            string pattern = @"^\d+$";
            return Regex.IsMatch(num, pattern);
           
        }
    }
}
