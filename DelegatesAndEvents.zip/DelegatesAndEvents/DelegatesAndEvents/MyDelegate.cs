﻿namespace DelegatesAndEvents
{
    public delegate void MyFirstDelegate();


}
