﻿namespace DelegatesAndEvents
{
    public delegate void GreetDelegate(string name);
}
