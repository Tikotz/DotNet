﻿using System;

namespace ReturningDelegates
{
}