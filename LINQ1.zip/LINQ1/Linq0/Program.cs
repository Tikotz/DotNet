﻿using System.Linq;


public class Program
{
    public static void Main()
    {

        //Func<int, bool> filter = x => x >= 0;
        //Predicate<int> filter1 = x => x >= 0;
        
        Console.WriteLine("****************************************************");

        int[] Numbers = new int[] { 10, 12, 5, 9, 87, -15, 3000,29 };

        //Fatch all Positive numbers with LINQ.
        var query1 = from num1 in Numbers 
                    where num1 >= 0
                    select num1;
        //Fatch all Positive numbers with LINQ and Lambda.
        var query1N = Numbers.Where(num1 => num1 >= 0);

        foreach (int item in query1)
        {
            Console.WriteLine(item);
        }
        Console.WriteLine("====================================================");
        foreach (int item in query1N)
        {
            Console.WriteLine(item);
        }
         


        Console.WriteLine("****************************************************");
        //Fetch all even numbers

        //Define the Query
        var quary2 = from number in Numbers
                     where number % 2 == 0
                     select number;

        //Execute the query
        foreach(var item in quary2)
        {
            Console.WriteLine(item);
        }
        Console.WriteLine("****************************************************");

        //Fatch all items of 'numbers' return it * 10
        var query3 = from number in Numbers
                     select number * 10;

        var list = query3;

        foreach(var item in list)
        {
            Console.WriteLine(item);
        }
        Console.WriteLine("****************************************************");

        var query4 = from number in Numbers
                     where number %2 == 0
                     select "or Ganon";
        //Execution1
        foreach(var item in query4)
        {
            Console.WriteLine(item);
        }

        //Execution2
        var liststr = query4.ToString();


        Console.WriteLine("****************************************************");

        string[] names = new string[] { "Ori", "avich", "Luffy", "Or","Lior"};
        var query5 = from name in names
                     where name.Contains("O") || name.Contains("o")
                     select name;
        foreach(var item in query5)
        {
            Console.WriteLine(item);
        }
        Console.WriteLine("****************************************************");

        var query6 = from name in names
                     where name.Length > 3
                     select name;

        foreach (var item in query6)
        {
            Console.WriteLine(item);
        }

        Console.WriteLine("****************************************************");

        var query7 = from number in Numbers
                     orderby number descending
                     select number;

        var arr = query7.ToArray();
        foreach(var item in arr)
        {
            Console.WriteLine(item);
        }

        Console.WriteLine("****************************************************");

        //Fatch 3 First items
        var quarry8N = Numbers.Take(3);//שאילתה
        var quarry8NList = Numbers.Take(3).ToList();//שאילתה והכנסה לתוך ליסט
        var list2 = quarry8N.ToList();//Execution
        foreach(var item in quarry8N)
        {
            Console.WriteLine(item);
        }
    }
}