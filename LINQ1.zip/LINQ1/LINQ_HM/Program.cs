﻿using LINQ_HM;
using System.Linq;

public class Program
{
    public static void Main()
    {
        //int[] Numbers = new int[] { 10, 12, 5, 9, 87, -15, 3000, 29 };
        ////HM QUESTION - 1:
        //var quarry1 = Numbers.Where(num => num < 0);
        //foreach (int num in quarry1)
        //{
        //    Console.WriteLine(num);
        //}
        //Console.WriteLine("===========================================================");

        ////HM QUESTION - 2:
        //var quarry2 = Numbers.Where(num => num % 2 == 0).OrderByDescending(num => num);

        //foreach (int num in quarry2)
        //{
        //    Console.WriteLine(num);
        //}

        //Console.WriteLine("===========================================================");


        ////HM QUESTION - 3:
        //var quarry3 = Numbers.Where(num => num % 3 == 0 && num > 5).Select(num => num *3);
        //foreach (int num in quarry3)
        //{
        //    Console.WriteLine(num);
        //}

        //Console.WriteLine("===========================================================");


        ////HM QUESTION - 4:
        //string[] Citys = new string[] {"xodya","tel aviv", "heifa", "jerusalem","herzeliya","xiamen" };

        //Console.WriteLine("Enter one chracter: ");
        //string input = Console.ReadLine();
        //var querry4 = Citys.Where(city => city.Contains(input)).Select(city => city);
        //foreach (string city in querry4)
        //{
        //    Console.WriteLine(city);
        //}

        //Console.WriteLine("===========================================================");


        ////HM QUESTION - 5:
        //Console.WriteLine("Enter one chracter: ");
        //string input2 = Console.ReadLine();
        //var querry5 = Citys.Where(city => city[0].ToString() == input2).Select(city => city);
        //foreach (string city in querry5)
        //{
        //    Console.WriteLine(city);
        //}

        //Console.WriteLine("===========================================================");


        ////HM QUESTION - 6:
        //var querry6 = Citys.Where(city => city.Contains("x")).Select(city => city);
        //foreach (string city in querry6)
        //{
        //    Console.WriteLine(city);
        //    break;
        //}

        //Console.WriteLine("===========================================================");


        ////HM QUESTION - 7:

        //var querry7 = Citys.OrderBy(city => city).Select(city => city);
        //int count = 0;
        //foreach (string city in querry7)
        //{
        //    if (count < 3)
        //    {
        //        Console.WriteLine(city);
        //    }
        //    else
        //    {
        //        break;
        //    }
        //    count++;
        //}


        Console.WriteLine("===========================================================");


        //HM QUESTION - 8:
        List<City> Cityslist = new List<City>();
        City City1 = new City(1,"Tel aviv",20000);
        City City2 = new City(2, "Jerusalem", 28500);
        City City3 = new City(3, "Herzeliya", 10000000);
        City City4 = new City(4, "Heifa", 5400);
        City City5 = new City(5, "Manhaten", 23080);
        City City6 = new City(6, "Hollywood", 9856000);
        Cityslist.Add(City1);
        Cityslist.Add(City2);
        Cityslist.Add(City3);
        Cityslist.Add(City4);
        Cityslist.Add(City5);
        Cityslist.Add(City6);

        var querry8 = Cityslist.Where(city => city.NumberOfPopulation > 25000).Select(city => city.ToString());
        foreach (var city in querry8)
        {
            Console.WriteLine(city);
        }


        Console.WriteLine("===========================================================");


        //HM QUESTION - 9:
        var querry9 = Cityslist.Where(city => city.NumberOfPopulation > 25000).Select(city => city.Name);
        foreach (var city in querry9)
        {
            Console.WriteLine(city);
        }

        var querry10 = Cityslist.Select(city => city.NumberOfPopulation > 25000 ? new {Name = city.Name, IsCity = "city"}: new {Name = city.Name, IsCity = "Town"});
        foreach (var city in querry10)
        {
            Console.WriteLine(city);
        }
    }
}
