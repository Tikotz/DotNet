﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hackerme.Infrastucture.Entities
{
    public class Courses
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime DateOfStart { get; set; }
        public int NumberOFMeetings { get; set; }
        public int PriceOfCourse { get; set; }

        public Courses(string name,int price)
        {
            Name = name;
            PriceOfCourse = price;
        }
        public override string ToString()
        {
            return Name;
        }
    }
}
