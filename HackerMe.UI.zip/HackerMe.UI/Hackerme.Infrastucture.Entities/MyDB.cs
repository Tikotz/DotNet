﻿using System;

namespace Hackerme.Infrastucture.Entities
{
    public class MyDB
    {
        public static List<Student> StudentsList = new List<Student>();

        public static List<Courses> CoursesList = new List<Courses>() { new Courses(".NET Basic",120), new Courses("OOP",140), new Courses("Core",80), new Courses("CSS",20), new Courses("HTML",70) };
    }
}
