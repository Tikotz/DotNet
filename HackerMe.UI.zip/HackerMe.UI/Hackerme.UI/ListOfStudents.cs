﻿using Hackerme.Infrastucture.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hackerme.UI
{
    public partial class ListOfStudents : UserControl
    {
        public ListOfStudents()
        {
            InitializeComponent();
            dataGridView1.DataSource = MyDB.StudentsList;
        }
    }
}
