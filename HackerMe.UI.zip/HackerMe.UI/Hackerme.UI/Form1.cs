﻿using Hackerme.Infrastucture.Entities;
using Hackerme.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Hackerme.UI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        


        List<Student> students = new List<Student>();
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void actionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StudentManagment manageStudent = new StudentManagment();
            manageStudent.Show(this);

        }

        private void addStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            panel1.Controls.Add(new ListOfStudents());
        }
    }
}
