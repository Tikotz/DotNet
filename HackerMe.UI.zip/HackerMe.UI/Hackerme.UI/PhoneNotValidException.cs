﻿using System.Runtime.Serialization;

namespace Hackerme.UI
{
    [Serializable]
    internal class PhoneNotValidException : Exception
    {
        public PhoneNotValidException()
        {
        }

        public PhoneNotValidException(string? message) : base(message)
        {
        }

        public PhoneNotValidException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected PhoneNotValidException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}