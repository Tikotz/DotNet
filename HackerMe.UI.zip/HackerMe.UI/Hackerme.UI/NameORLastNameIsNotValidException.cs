﻿using System.Runtime.Serialization;

namespace Hackerme.UI
{
    [Serializable]
    internal class NameORLastNameIsNotValidException : Exception
    {
        public NameORLastNameIsNotValidException()
        {
        }

        public NameORLastNameIsNotValidException(string? message) : base(message)
        {
        }

        public NameORLastNameIsNotValidException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected NameORLastNameIsNotValidException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}