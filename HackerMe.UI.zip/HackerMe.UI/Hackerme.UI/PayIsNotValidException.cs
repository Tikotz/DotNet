﻿using System.Runtime.Serialization;

namespace Hackerme.UI
{
    [Serializable]
    internal class PayIsNotValidException : Exception
    {
        public PayIsNotValidException()
        {
        }

        public PayIsNotValidException(string? message) : base(message)
        {
        }

        public PayIsNotValidException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected PayIsNotValidException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}