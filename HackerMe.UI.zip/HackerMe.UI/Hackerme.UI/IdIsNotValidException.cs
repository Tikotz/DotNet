﻿using System.Runtime.Serialization;

namespace Hackerme.UI
{
    [Serializable]
    internal class IdIsNotValidException : Exception
    {
        public IdIsNotValidException()
        {
        }

        public IdIsNotValidException(string? message) : base(message)
        {
        }

        public IdIsNotValidException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected IdIsNotValidException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}