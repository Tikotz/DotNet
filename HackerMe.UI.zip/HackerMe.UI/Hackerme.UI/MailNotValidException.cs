﻿using System.Runtime.Serialization;

namespace Hackerme.UI
{
    [Serializable]
    internal class MailNotValidException : Exception
    {
        public MailNotValidException()
        {
        }

        public MailNotValidException(string? message) : base(message)
        {
        }

        public MailNotValidException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected MailNotValidException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}