﻿using Hackerme.Infrastucture.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hackerme.Infrastucture.Entities;
using System.Text.RegularExpressions;

namespace Hackerme.UI
{
    public partial class StudentsControl : UserControl
    {
        public StudentsControl()
        {
            InitializeComponent();
            foreach (var course in MyDB.CoursesList)
            {
                checkedListBox1.Items.Add(course);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                var ValidPay = new Regex(@"^([0-9]*)$");
                bool IsPayMach = ValidPay.IsMatch(Pay.Text);
                if (IsPayMach == false)
                {
                    throw new PayIsNotValidException();
                }
                var ValidNameORLastname = new Regex(@"\D\S$");
                bool IsNameMach = ValidNameORLastname.IsMatch(first.Text);
                bool IsLastNameMach = ValidNameORLastname.IsMatch(last.Text);
                if (IsLastNameMach == false && IsLastNameMach == false)
                {
                    throw new NameORLastNameIsNotValidException();
                }
                var ValidId = new Regex(@"^\d{9}$");//Valid ID.
                bool isIdMach = ValidId.IsMatch(Id.Text);
                if (isIdMach == false)
                {
                    throw new IdIsNotValidException();
                }
                var ValidPhoneNumber = new Regex(@"^([0-9]{3})([0-9]{7})$");//valid phone number.
                bool isPhonemach = ValidPhoneNumber.IsMatch(PhoneNumber.Text);
                if (isPhonemach == false)
                {
                    throw new PhoneNotValidException();
                }
                var regex = new Regex(@"^([\w\.]+)@([\w\-]+)((\.(\w){2,3})+)$");//valid Email adress.
                bool ismach = regex.IsMatch(EmailTextBox.Text);
                if (ismach == false)
                {
                    throw new MailNotValidException();
                }
                MyDB.StudentsList.Add(new Student(Id.Text, first.Text, last.Text, PhoneNumber.Text, dateTimePicker1.Value.Date, EmailTextBox.Text, city.Text, int.Parse(PriceTextBox.Text), int.Parse(Pay.Text)));
                foreach (var course in checkedListBox1.CheckedItems)
                {
                    foreach (var item in MyDB.CoursesList)
                    {
                        if (course.ToString() == item.Name)
                        {
                            MyDB.StudentsList[MyDB.StudentsList.Count - 1].CoursesWhoParticipant.Add(item);
                        }
                    }
                }
                MessageBox.Show("Student Is Added Sucssesfuly");
            }
            catch (NameORLastNameIsNotValidException)
            {
                MessageBox.Show("Name OR LastName Contains ONLY Lettrs");
            }
            catch (IdIsNotValidException)
            {
                MessageBox.Show("ID Contains ONLY Digits");
            }
            catch (MailNotValidException)
            {
                MessageBox.Show("Check your Email...");
            }
            catch (PhoneNotValidException)
            {
                MessageBox.Show("Check your phone number !");
            }
            catch (PayIsNotValidException)
            {
                MessageBox.Show("Chack your pay method");
            }
            catch
            {
                MessageBox.Show("Somthing is wrong try again");
            }
            
        }
        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int price = 0;
            foreach (var course in checkedListBox1.CheckedItems)
            {
                foreach (var item in MyDB.CoursesList)
                {
                    if (course.ToString() == item.Name)
                    {
                        price += Convert.ToInt32(item.PriceOfCourse);
                        //PriceTextBox.Text = price.ToString();
                    }
                }
            }
            PriceTextBox.Text = price.ToString();
        }
    }
}
