﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Hackerme.Infrastucture.Entities;

namespace Hackerme.UI
{
    public partial class SerchAndDelete : UserControl
    {
        public SerchAndDelete()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var item in MyDB.StudentsList)
            {
                if (item.Id == textBox1.Text)
                {
                    propertyGrid1.SelectedObject = item;
                    textBox1.ReadOnly = true;
                    break;
                }
            }

        }

        private void saveStudent_Click(object sender, EventArgs e)
        {
            propertyGrid1.SelectedObject = null;
            textBox1.ReadOnly = false;
            MessageBox.Show("Saved!!");

        }

        private void DeleteStudent_Click(object sender, EventArgs e)
        {
            foreach (var item in MyDB.StudentsList)
            {
                if (item.Id == textBox1.Text)
                {
                    MyDB.StudentsList.Remove(item);
                    propertyGrid1.SelectedObject = null;
                    textBox1.ReadOnly = false;
                    break;
                }
            }
        }
    }
}
