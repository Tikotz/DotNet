﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hackerme.UI
{
    public partial class StudentManagment : Form
    {
        public StudentManagment()
        {
            InitializeComponent();
        }

        private void addStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManagamentPanel.Controls.Clear();
            ManagamentPanel.Controls.Add(new StudentsControl());
        }

        private void deleteStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManagamentPanel.Controls.Clear();
            ManagamentPanel.Controls.Add(new SerchAndDelete());
        }
    }
}
